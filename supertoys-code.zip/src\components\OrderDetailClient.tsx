'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { getOrder } from '@/lib/db'
import type { Order } from '@/types'
import { ArrowLeft, MapPin, Phone, User, Truck, Clock, CheckCircle, Package, Copy, CreditCard, MessageCircle } from 'lucide-react'
import Link from 'next/link'

const statusConfig: Record<string, { label: string; icon: any; color: string }> = {
  paid: { label: '待发货', icon: Clock, color: 'text-[var(--accent)]' },
  shipped: { label: '运输中', icon: Truck, color: 'text-purple-600' },
  delivered: { label: '已送达', icon: CheckCircle, color: 'text-green-600' },
  cancelled: { label: '已取消', icon: Package, color: 'text-gray-400' },
}

export default function OrderDetailClient() {
  const params = useParams()
  const router = useRouter()
  const orderId = params.id ? decodeURIComponent(params.id as string) : ''
  const [order, setOrder] = useState<Order | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const user = localStorage.getItem('currentUser')
    if (!user) {
      router.push('/login')
      return
    }
    if (orderId) {
      getOrder(orderId).then(o => {
        setOrder(o || null)
        setLoading(false)
      })
    }
  }, [orderId, router])

  // ... rest of the order detail UI
  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="animate-pulse text-gray-400 text-center py-20">加载中...</div>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <p className="text-gray-400">订单不存在</p>
        <Link href="/orders" className="mt-4 inline-block text-sm text-blue-600 hover:underline">返回订单列表</Link>
      </div>
    )
  }

  const status = statusConfig[order.status] || statusConfig.paid
  const StatusIcon = status.icon

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <button onClick={() => router.back()} className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-900 mb-6 transition-colors">
        <ArrowLeft size={16} /> 返回
      </button>

      {/* Order Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">订单详情</h1>
          <p className="text-xs text-gray-400 mt-1 font-mono">订单号: {order.id}</p>
        </div>
        <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium ${status.color.replace('text-', 'bg-').replace('600', '50')} ${status.color}`}>
          <StatusIcon size={14} />
          {status.label}
        </div>
      </div>

      {/* Items */}
      <div className="bg-white border border-[var(--border-light)] p-4 mb-4">
        <h2 className="text-[13px] font-bold text-[var(--foreground)] mb-3">商品信息</h2>
        <div className="space-y-3">
          {order.items.map((item, i) => (
            <div key={i} className="flex items-center gap-3">
              <img src={item.imageUrl} alt={item.name} className="w-14 h-14 object-cover rounded-lg bg-gray-50 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-[13px] font-medium text-[var(--foreground)] truncate">{item.name}</p>
                <p className="text-[11px] text-[var(--text-tertiary)] mt-0.5">x{item.quantity}</p>
              </div>
              <p className="text-[13px] font-bold">¥{(item.price * item.quantity).toFixed(2)}</p>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between pt-3 mt-3 border-t border-[var(--border-light)]">
          <span className="text-[13px] text-[var(--text-secondary)]">合计</span>
          <span className="text-[16px] font-bold text-[var(--accent)]">¥{order.total.toFixed(2)}</span>
        </div>
      </div>

      {/* Shipping Info */}
      <div className="bg-white border border-[var(--border-light)] p-4 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <MapPin size={15} className="text-[var(--text-tertiary)]" />
          <h2 className="text-[13px] font-bold text-[var(--foreground)]">收货信息</h2>
        </div>
        <div className="space-y-2 text-[13px] text-[var(--text-secondary)]">
          <div className="flex items-center gap-2"><User size={14} className="text-gray-300" />{order.recipient}</div>
          <div className="flex items-center gap-2"><Phone size={14} className="text-gray-300" />{order.phone}</div>
          <div className="flex items-start gap-2"><MapPin size={14} className="text-gray-300 mt-0.5" />{order.shippingAddress}</div>
        </div>
      </div>

      {/* Tracking Info */}
      {order.trackingNumber && (
        <div className="bg-white border border-[var(--border-light)] p-4 mb-4">
          <div className="flex items-center gap-2 mb-3">
            <Truck size={15} className="text-[var(--text-tertiary)]" />
            <h2 className="text-[13px] font-bold text-[var(--foreground)]">物流信息</h2>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[13px] text-[var(--text-secondary)]">{order.carrier}</p>
              <p className="text-[12px] text-[var(--text-tertiary)] font-mono mt-0.5">{order.trackingNumber}</p>
            </div>
            <button onClick={() => navigator.clipboard.writeText(order.trackingNumber || '')} className="flex items-center gap-1 text-[11px] text-gray-400 hover:text-gray-700">
              <Copy size={12} /> 复制
            </button>
          </div>
        </div>
      )}

      {/* Payment Method */}
      <div className="bg-white border border-[var(--border-light)] p-4 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <CreditCard size={15} className="text-[var(--text-tertiary)]" />
          <h2 className="text-[13px] font-bold text-[var(--foreground)]">付款方式</h2>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-white border border-[var(--border-light)] p-2 flex items-center justify-center">
            <img src="/assets/images/payments/Paypal-Logo-2022.png" alt="PayPal" className="h-7" />
          </div>
          <div>
            <span className="text-[13px] text-[var(--foreground)] font-medium">PayPal</span>
            <p className="text-[11px] text-[var(--text-tertiary)]">s***3@163.com</p>
          </div>
        </div>
      </div>

      {/* Date */}
      <p className="text-[11px] text-[var(--text-tertiary)] text-center">下单时间: {new Date(order.createdAt).toLocaleString('zh-CN')}</p>
    </div>
  )
}
